<?php
if (!isset($_SESSION['login'])) {
    echo "<script>location='assets/'</script>";
}
?>
<section class="section dashboard">
    <div class="row">
        <div class="col-12">
            <div class="card recent-sales overflow-auto">
                <div class="card-body">
                    <h5 class="card-title"><?= @$_GET["p"] ?></h5>
                    <?php if ($_SESSION['level'] != "super admin" and $_SESSION['level'] != "admin") { ?>
                        <a href="?d=Form Laporan&p=Laporan Locotrack" class="btn btn-primary mb-3">
                            Tambah Locotrack
                        </a>
                    <?php
                    }
                    ?>
                    <table class="table table-borderless" id="dataTable3">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode</th>
                                <th scope="col">Foto</th>
                                <th scope="col">Nama Locotrack</th>
                                <th scope="col">Status</th>
                                <?php if ($_SESSION['level'] == "teknisi") { ?>
                                    <th scope="col">Aksi</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            $result = $db->getDataPerangkat('Locotrack');
                            while ($d = mysqli_fetch_assoc($result)) {
                                $db->editDataPerangkat($d['id'], $d['foto'], 'Locotrack');
                                $db->deleteDataPerangkat($d['id'], 'Locotrack');
                            ?>
                                <tr>
                                    <th scope="row"><?= $i++ ?></th>
                                    <td><?= $d['kode'] ?></td>
                                    <td><img src="assets/upload/<?= $d['foto'] ?>" width="100"></td>
                                    <td><?= $d['nama'] ?></td>
                                    <td>
                                        <?php if ($d['status'] == "Normal") { ?>
                                            <span class="badge bg-success"><?= $d['status'] ?></span>
                                        <?php } ?>
                                        <?php if ($d['status'] == "Pemeliharaan") { ?>
                                            <span class="badge bg-warning"><?= $d['status'] ?></span>
                                        <?php } ?>
                                        <?php if ($d['status'] == "Rusak") { ?>
                                            <span class="badge bg-danger"><?= $d['status'] ?></span>
                                        <?php } ?>
                                    </td>
                                    <?php if ($_SESSION['level'] == "teknisi") { ?>
                                        <td>
                                            <a href="#" class="btn btn-warning my-1" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $d['id'] ?>">Edit</a>
                                            <form action="" method="post">
                                                <button type="submit" name="delete<?= $d['id'] ?>" class="btn btn-danger my-1">Delete</button>
                                            </form>
                                        </td>
                                    <?php } ?>
                                </tr>
                                <div class="modal fade" id="exampleModal<?= $d['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Data</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="" method="post">
                                                <div class="modal-body">
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['kode'] ?>" placeholder="Kode" name="kode" required>
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['nama'] ?>" placeholder="Nama Locotrack" name="nama" required>
                                                    <select class="form-select" aria-label="Default select example" name="status" required>
                                                        <option value="Normal" <?= $d['status'] == "Normal" ? 'selected' : ''; ?>>Normal</option>
                                                        <option value="Pemeliharaan" <?= $d['status'] == "Pemeliharaan" ? 'selected' : ''; ?>>Pemeliharaan</option>
                                                        <option value="Rusak" <?= $d['status'] == "Rusak" ? 'selected' : ''; ?>>Rusak</option>
                                                    </select>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" name="editlocotrack<?= $d['id'] ?>" class="btn btn-warning">Edit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>