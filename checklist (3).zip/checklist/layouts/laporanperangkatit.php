<?php
if (!isset($_SESSION['login']) || $_SESSION['level'] != 'teknisi') {
    echo "<script>location='assets/'</script>";
}
$db->tambahDataPerangkat('Perangkat IT');
?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?= @$_GET["p"] ?></h5>
                    <form method="post" enctype="multipart/form-data">
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Kode</label>
                            <div class="col-sm-10"> <input type="text" name="kode" class="form-control" required></div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Foto</label>
                            <div class="col-sm-10"> <input type="file" name="foto" class="form-control" required></div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Jenis Perangkat IT</label>
                            <div class="col-sm-10"> <input type="text" name="jenis" class="form-control" required></div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Nama Perangkat IT</label>
                            <div class="col-sm-10"> <input type="text" name="nama" class="form-control" required></div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label">Status</label>
                            <div class="col-sm-10">
                                <select class="form-select" aria-label="Default select example" name="status" required>
                                    <option value="Baik">Baik</option>
                                    <option value="Pemeliharaan">Pemeliharaan</option>
                                    <option value="Rusak">Rusak</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-sm-2"> <button type="reset" class="btn btn-danger">Batal</button> </div>
                            <div class="col-sm-10"> <button type="submit" class="btn btn-primary" name="tambah">Submit</button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>