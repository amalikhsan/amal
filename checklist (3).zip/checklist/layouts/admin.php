<?php
if (!isset($_SESSION['login'])) {
    echo "<script>location='assets/'</script>";
}
if ($_SESSION['level'] != "super admin") {
    echo "<script>location='index.php'</script>";
}
$db->tambahAkun('admin');
?>
<section class="section dashboard">
    <div class="row">
        <div class="col-12">
            <div class="card recent-sales overflow-auto">
                <div class="card-body">
                    <h5 class="card-title"><?= @$_GET["p"] ?></h5>
                    <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        Tambah Akun
                    </button>
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Akun</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <input type="text" class="form-control w-100 mb-3" placeholder="Nama" name="nama">
                                        <input type="email" class="form-control w-100 mb-3" placeholder="Email" name="email">
                                        <input type="number" class="form-control w-100 mb-3" placeholder="Nipp" name="nipp">
                                        <input type="number" class="form-control w-100 mb-3" placeholder="Nomor" name="nomor">
                                        <input type="text" class="form-control w-100 mb-3" placeholder="Username" name="username">
                                        <input type="text" class="form-control w-100 mb-3" placeholder="Jabatan" name="jabatan">
                                        <input type="text" class="form-control w-100 mb-3" placeholder="Asal" name="asal">
                                        <textarea type="text" class="form-control w-100 mb-3" placeholder="Alamat" name="alamat"></textarea>
                                        <input type="text" class="form-control w-100 mb-3" placeholder="Password" name="password">
                                        <input type="file" class="form-control w-100 mb-3" name="foto">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary">Batal</button>
                                        <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <table class="table table-borderless" id="dataTable3">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Email</th>
                                <th scope="col">Nipp</th>
                                <th scope="col">Nomor</th>
                                <th scope="col">Username</th>
                                <th scope="col">Jabatan</th>
                                <th scope="col">Asal</th>
                                <th scope="col">Alamat</th>
                                <th scope="col">Password</th>
                                <th scope="col">Level</th>
                                <th scope="col">Foto</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            $result = $db->getAkun('admin');
                            while ($d = mysqli_fetch_assoc($result)) {
                                $db->editAkun($d['id'], $d['foto'], 'admin');
                                $db->deleteAkun($d['id'], 'admin');
                            ?>
                                <tr>
                                    <th scope="row"><?= $i++ ?></th>
                                    <td><?= $d['nama'] ?></td>
                                    <td><?= $d['email'] ?></td>
                                    <td><?= $d['nipp'] ?></td>
                                    <td><?= $d['nomor'] ?></td>
                                    <td><?= $d['username'] ?></td>
                                    <td><?= $d['jabatan'] ?></td>
                                    <td><?= $d['asal'] ?></td>
                                    <td><?= $d['alamat'] ?></td>
                                    <td><?= $d['password'] ?></td>
                                    <td><?= $d['level'] ?></td>
                                    <td><img src="assets/upload/<?= $d['foto'] ?>" width="100"></td>
                                    <td>
                                        <a href="#" class="btn btn-warning my-1" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $d['id'] ?>">Edit</a>
                                        <form action="" method="post">
                                            <button type="submit" name="delete<?= $d['id'] ?>" class="btn btn-danger my-1">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <div class="modal fade" id="exampleModal<?= $d['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Akun</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="" method="post" enctype="multipart/form-data">
                                                <div class="modal-body">
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['nama'] ?>" placeholder="Nama" name="nama">
                                                    <input type="email" class="form-control w-100 mb-3" value="<?= $d['email'] ?>" placeholder="Email" name="email">
                                                    <input type="number" class="form-control w-100 mb-3" value="<?= $d['nipp'] ?>" placeholder="Nipp" name="nipp">
                                                    <input type="number" class="form-control w-100 mb-3" value="<?= $d['nomor'] ?>" placeholder="Nomor" name="nomor">
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['username'] ?>" placeholder="Username" name="username">
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['jabatan'] ?>" placeholder="Jabatan" name="jabatan">
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['asal'] ?>" placeholder="Asal" name="asal">
                                                    <textarea type="text" class="form-control w-100 mb-3" placeholder="Alamat" name="alamat"><?= $d['alamat'] ?></textarea>
                                                    <input type="text" class="form-control w-100 mb-3" value="<?= $d['password'] ?>" placeholder="Password" name="password">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" name="edit<?= $d['id'] ?>" class="btn btn-warning">Edit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>