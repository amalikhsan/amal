<?php
if (!isset($_SESSION['login'])) {
    echo "<script>location='assets/'</script>";
}
$result = $db->sesdata($_SESSION['id']);
while ($d = mysqli_fetch_assoc($result)) {
    $db->profil($d["id"]);
?>
    <section class="section profile">
        <div class="row">
            <div class="col-xl-4">
                <div class="card">
                    <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                        <img src="assets/upload/<?= @$d['foto'] ?>" alt="Profile" class="rounded-circle" width="100%" height="130">
                        <h2><?= @$d['nama'] ?></h2>
                        <h3><?= @$d['jabatan'] ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="card">
                    <div class="card-body pt-3">
                        <ul class="nav nav-tabs nav-tabs-bordered">
                            <li class="nav-item"> <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Ringkasan</button></li>
                            <li class="nav-item"> <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profil</button></li>
                            <li class="nav-item"> <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Ganti Password</button></li>
                        </ul>
                        <div class="tab-content pt-2">
                            <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                <h5 class="card-title">Detail Profil</h5>
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Username</div>
                                    <div class="col-lg-9 col-md-8"><?= @$d['username'] ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Tentang</div>
                                    <div class="col-lg-9 col-md-8"><?= @$d['tentang'] ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Telepon</div>
                                    <div class="col-lg-9 col-md-8"><?= @$d['nomor'] ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Email</div>
                                    <div class="col-lg-9 col-md-8"><a href="mailto:<?= @$d['email'] ?>" class="__cf_email__"><?= @$d['email'] ?></a></div>
                                </div>
                            </div>
                            <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                                <form method="post">
                                    <div class="row mb-3">
                                        <label for="username" class="col-md-4 col-lg-3 col-form-label">Username</label>
                                        <div class="col-md-8 col-lg-9"> <input name="username" type="text" class="form-control" id="username" value="<?= @$d['username'] ?>"></div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="tentang" class="col-md-4 col-lg-3 col-form-label">Tentang</label>
                                        <div class="col-md-8 col-lg-9"><textarea name="tentang" class="form-control" id="tentang" style="height: 100px"><?= @$d['tentang'] ?></textarea></div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="telepon" class="col-md-4 col-lg-3 col-form-label">Telepon</label>
                                        <div class="col-md-8 col-lg-9"> <input name="nomor" type="number" class="form-control" id="telepon" value="<?= @$d['nomor'] ?>"></div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                                        <div class="col-md-8 col-lg-9"> <input name="email" type="email" class="form-control" id="email" value="<?= @$d['email'] ?>"></div>
                                    </div>
                                    <div class="text-center"> <button type="submit" class="btn btn-primary" name="edit<?= $d["id"] ?>">Edit Profil</button></div>
                                </form>
                            </div>
                            <div class="tab-pane fade pt-3" id="profile-change-password">
                                <form method="post">
                                    <div class="row mb-3">
                                        <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label"> Password Sekarang</label>
                                        <div class="col-md-8 col-lg-9"> <input name="password" type="password" class="form-control" id="currentPassword"></div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">Password Baru</label>
                                        <div class="col-md-8 col-lg-9"> <input name="newpassword" type="password" class="form-control" id="newPassword"></div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Konfirmasi Password Baru</label>
                                        <div class="col-md-8 col-lg-9"> <input name="renewpassword" type="password" class="form-control" id="renewPassword"></div>
                                    </div>
                                    <div class="text-center"> <button type="submit" class="btn btn-primary" name="gantipass<?= $d["id"] ?>">Ganti Password</button></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php
}
?>