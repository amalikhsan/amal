<?php
if (!isset($_SESSION['login'])) {
    echo "<script>location='assets/'</script>";
}
?>
<section class="section dashboard">
    <div class="row">
        <div class="col-12">
            <div class="card recent-sales overflow-auto">
                <div class="card-body">
                    <h5 class="card-title"><?= @$_GET["p"] ?></h5>
                    <table class="table table-borderless" id="dataTable3">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Email</th>
                                <th scope="col">Nipp</th>
                                <th scope="col">Nomor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            $result = $db->getAkun('teknisi');
                            while ($d = mysqli_fetch_assoc($result)) {
                            ?>
                                <tr>
                                    <th scope="row"><?= $i++ ?></th>
                                    <td><?= $d['nama'] ?></td>
                                    <td><a href="mailto:<?= $d['email'] ?>" class="__cf_email__"><?= $d['email'] ?></a></td>
                                    <td><?= $d['nipp'] ?></td>
                                    <td><?= $d['nomor'] ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>