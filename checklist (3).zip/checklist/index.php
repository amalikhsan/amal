<?php
session_start();
require_once 'assets/config/config.php';
if (!isset($_SESSION['login'])) {
   echo "<script>location='assets/'</script>";
}
$db = new db();
?>
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <title><?= empty($_GET['p']) ? "DASHBOARD" : $_GET['p']; ?> PT. KAI DIVRE III PALEMBANG</title>
   <meta name="robots" content="noindex, nofollow">
   <meta content="PT. KAI DIVRE III PALEMBANG" name="description">
   <meta content="KAI" name="keywords">
   <link href="assets/img/ptkai.png" rel="icon">
   <link href="https://fonts.gstatic.com" rel="preconnect">
   <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
   <link href="assets/css/bootstrap.min.css" rel="stylesheet">
   <link href="assets/css/bootstrap-icons.css" rel="stylesheet">
   <link href="assets/css/boxicons.min.css" rel="stylesheet">
   <link href="assets/css/quill.snow.css" rel="stylesheet">
   <link href="assets/css/quill.bubble.css" rel="stylesheet">
   <link href="assets/css/remixicon.css" rel="stylesheet">
   <link href="assets/css/simple-datatables.css" rel="stylesheet">
   <link href="assets/css/style.css" rel="stylesheet">
   <script>
      if (window.history.replaceState) {
         window.history.replaceState(null, null, window.location.href);
      }
   </script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
   <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-144808195-1"></script>
   <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
         dataLayer.push(arguments);
      }
      gtag('js', new Date());

      gtag('config', 'UA-144808195-1');
   </script>
</head>

<body>
   <header id="header" class="header fixed-top d-flex align-items-center">
      <div class="d-flex align-items-center"><a href="index.php" class="logo d-flex align-items-center"><img src="assets/img/ptkai.png" width="100" class="me-2"><span class="d-lg-inline d-none">PT. KAI DIVRE III PALEMBANG</span> </a> <i class="bi bi-list toggle-sidebar-btn"></i></div>
      <div class="search-bar">
         <form class="search-form d-flex align-items-center" method="get">
            <input type="text" name="query" placeholder="Search" title="Enter search keyword">
            <button type="submit" title="Search"><i class="bi bi-search"></i></button>
         </form>
      </div>
      <nav class="header-nav ms-auto">
         <ul class="d-flex align-items-center">
            <li class="nav-item d-block d-lg-none"> <a class="nav-link nav-icon search-bar-toggle " href="#"> <i class="bi bi-search"></i> </a></li>
            <li class="nav-item dropdown pe-3">
               <a class="nav-link nav-profil d-flex align-items-center pe-0 text-dark" href="#" data-bs-toggle="dropdown"> <img src="assets/upload/<?= @$_SESSION["foto"] ?>" alt="Profil" class="rounded-circle" width="30" height="30"> <span class="d-none d-md-block dropdown-toggle ps-2"><?= @$_SESSION["name"] ?></span> </a>
               <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profil">
                  <li class="dropdown-header">
                     <img src="assets/upload/<?= @$_SESSION["foto"] ?>" alt="Profil" class="rounded-circle mx-3" width="100" height="100">
                     <h4 class="text-dark fw-bold mb-0"><?= @$_SESSION["nama"] ?></h4>
                     <span><?= @$_SESSION["jabatan"] ?></span>
                  </li>
                  <li>
                     <hr class="dropdown-divider">
                  </li>
                  <li> <a class="dropdown-item d-flex align-items-center" href="?p=Profil"> <i class="bi bi-person"></i> <span>Profil</span> </a></li>
                  <li>
                     <hr class="dropdown-divider">
                  </li>
                  <li> <a class="dropdown-item d-flex align-items-center" href="?p=Kontak"> <i class="bi bi-envelope"></i> <span>Kontak</span> </a></li>
                  <li>
                     <hr class="dropdown-divider">
                  </li>
                  <li> <a class="dropdown-item d-flex align-items-center" href="?p=Signout"> <i class="bi bi-box-arrow-right"></i> <span>Keluar</span> </a></li>
               </ul>
            </li>
         </ul>
      </nav>
   </header>
   <aside id="sidebar" class="sidebar">
      <ul class="sidebar-nav" id="sidebar-nav">
         <li class="nav-item"> <a class="nav-link <?= isset($_GET["p"]) ? 'collapsed' : ''; ?>" href="index.php"> <i class="bi bi-grid"></i> <span>Dashboard</span> </a></li>
         <?php if ($_SESSION['level'] == "super admin" || $_SESSION['level'] == "admin") { ?>
            <li class="nav-item">
               <a class="nav-link collapsed" data-bs-target="#pengguna-nav" data-bs-toggle="collapse" href="#"> <i class="bi bi-person"></i><span>Data Pengguna</span><i class="bi bi-chevron-down ms-auto"></i> </a>
               <ul id="pengguna-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                  <?php if ($_SESSION['level'] == "super admin") { ?>
                     <li> <a href="?d=Data Pengguna&p=Admin" class="<?= @$_GET["p"] == "Admin" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Admin</span> </a></li>
                  <?php } ?>
                  <li> <a href="?d=Data Pengguna&p=Teknisi" class="<?= @$_GET["p"] == "Teknisi" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Teknisi</span> </a></li>
               </ul>
            </li>
         <?php } ?>
         <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#perangkat-nav" data-bs-toggle="collapse" href="#"> <i class="bi bi-menu-button-wide"></i><span>Data Perangkat</span><i class="bi bi-chevron-down ms-auto"></i> </a>
            <ul id="perangkat-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
               <li> <a href="?d=Data Perangkat&p=CCTV Gerbong" class="<?= @$_GET["p"] == "CCTV Gerbong" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>CCTV Gerbong</span> </a></li>
               <li> <a href="?d=Data Perangkat&p=Locotrack" class="<?= @$_GET["p"] == "Locotrack" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Locotrack</span> </a></li>
               <li> <a href="?d=Data Perangkat&p=Perangkat IT" class="<?= @$_GET["p"] == "Perangkat IT" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Perangkat IT</span> </a></li>
            </ul>
         </li>
         <?php if ($_SESSION['level'] == "teknisi") { ?>
            <li class="nav-item">
               <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#"> <i class="bi bi-journal-text"></i><span>Form Laporan</span><i class="bi bi-chevron-down ms-auto"></i> </a>
               <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                  <li> <a href="?d=Form Laporan&p=Laporan CCTV" class="<?= @$_GET["p"] == "Laporan CCTV" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Laporan CCTV</span> </a></li><s></s>
                  <li> <a href="?d=Form Laporan&p=Laporan Locotrack" class="<?= @$_GET["p"] == "Laporan Locotrack" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Laporan Lokotrack</span> </a></li><s></s>
                  <li> <a href="?d=Form Laporan&p=Laporan Perangkat IT" class="<?= @$_GET["p"] == "Laporan Perangkat IT" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Laporan Perangkat IT</span> </a></li><s></s>
               </ul>
            </li>
         <?php } ?>
         <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#"> <i class="bi bi-layout-text-window-reverse"></i><span>Teknisi</span><i class="bi bi-chevron-down ms-auto"></i> </a>
            <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
               <li> <a href="?d=Teknisi&p=Data Teknisi" class="<?= @$_GET["p"] == "Data Teknisi" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Data Teknisi</span> </a></li>
               <li> <a href="?d=Teknisi&p=Jadwal Kerja Teknisi" class="<?= @$_GET["p"] == "Jadwal Kerja Teknisi" ? 'active' : ''; ?>"> <i class="bi bi-circle"></i><span>Jadwal Kerja Teknisi</span> </a></li>
            </ul>
         </li>
         <li class="nav-heading">Pages</li>
         <li class="nav-item"> <a class="nav-link <?= @$_GET["p"] == "Profil" ? '' : 'collapsed'; ?>" href="?p=Profil"> <i class="bi bi-person"></i> <span>Profil</span> </a></li>
         <li class="nav-item"> <a class="nav-link <?= @$_GET["p"] == "Kontak" ? '' : 'collapsed'; ?>" href="?p=Kontak"> <i class="bi bi-envelope"></i> <span>kontak</span> </a></li>
      </ul>
   </aside>
   <main id="main" class="main">
      <div class="pagetitle">
         <h1><?= @$_GET["p"] ? $_GET["p"] : "Dashboard"; ?></h1>
         <nav>
            <ol class="breadcrumb">
               <li class="breadcrumb-item"><a href="index.php">Home</a></li>
               <?php if (!empty(@$_GET["d"])) { ?><li class="breadcrumb-item"><?= @$_GET["d"]; ?></li><?php } ?>
               <li class="breadcrumb-item active"><?= @$_GET["p"] ? $_GET["p"] : "Dashboard"; ?></li>
            </ol>
         </nav>
      </div>
      <?php
      $page = @$_GET["p"];
      switch ($page) {
         case 'Admin':
            require_once 'layouts/admin.php';
            break;
         case 'Teknisi':
            require_once 'layouts/teknisi.php';
            break;
         case 'CCTV Gerbong':
            require_once 'layouts/cctvgrebong.php';
            break;
         case 'Locotrack':
            require_once 'layouts/locotrack.php';
            break;
         case 'Perangkat IT':
            require_once 'layouts/perangkatit.php';
            break;
         case 'Laporan CCTV':
            require_once 'layouts/laporancctv.php';
            break;
         case 'Laporan Locotrack':
            require_once 'layouts/laporanlocotrack.php';
            break;
         case 'Laporan Perangkat IT':
            require_once 'layouts/laporanperangkatit.php';
            break;
         case 'Data Teknisi':
            require_once 'layouts/datateknisi.php';
            break;
         case 'Jadwal Kerja Teknisi':
            require_once 'layouts/jadwalkerjateknisi.php';
            break;
         case 'Profil':
            require_once 'layouts/profil.php';
            break;
         case 'Kontak':
            require_once 'layouts/kontak.php';
            break;
         case 'Signout':
            require_once 'signout.php';
            break;

         default:
            require_once 'layouts/dashboard.php';
            break;
      }
      ?>
   </main>
   <footer id="footer" class="footer">
      <div class="copyright">Copyright &copy; <?= date("Y") ?> <strong><span>Kelompok Tiga</span></strong>. All Rights Reserved</div>
      <div class="credits">Create By <a href="index.php">Kelompok Tiga</a></div>
   </footer>
   <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
   <script src="assets/js/apexcharts.min.js"></script>
   <script src="assets/js/bootstrap.bundle.min.js"></script>
   <script src="assets/js/chart.min.js"></script>
   <script src="assets/js/echarts.min.js"></script>
   <script src="assets/js/quill.min.js"></script>
   <script src="assets/js/simple-datatables.js"></script>
   <script src="assets/js/tinymce.min.js"></script>
   <script src="assets/js/validate.js"></script>
   <script src="assets/js/main.js"></script>


   <script>
      $(document).ready(function() {
         $('#dataTable3').DataTable({
            dom: 'Bfrtip',
            buttons: [
               'copy', 'csv', 'excel', 'pdf', 'print',
            ]
         });
      });
      $(document).ready(function() {
         $('#dataTable4').DataTable({
            buttons: [
               'copy', 'csv', 'excel', 'pdf', 'print',
            ]
         });
      });
      $(document).ready(function() {
         $('#dataTable5').DataTable({
            buttons: [
               'copy', 'csv', 'excel', 'pdf', 'print',
            ]
         });
      });
   </script>

   <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
   <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
</body>

</html>