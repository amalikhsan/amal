<?php

class db
{
    public function __construct(
        $server = "localhost",
        $uname = "root",
        $pass = "",
        $db = "kai_divre_iii_plg"
    ) {
        $this->server = $server;
        $this->uname = $uname;
        $this->pass = $pass;
        $this->db = $db;

        $this->con = mysqli_connect($this->server, $this->uname, $this->pass, $this->db);
        if (!$this->con) {
            die("Could not connect to db");
        }
    }
    public function login()
    {
        if (isset($_POST['login'])) {
            $username = htmlspecialchars($_POST["username"]);
            if (strlen($username) == 0) {
                echo "<script>alert('Gagal Login')</script>";
                return false;
            }
            $password = htmlspecialchars($_POST["password"]);
            if (strlen($password) == 0) {
                echo "<script>alert('Gagal Login')</script>";
                return false;
            }
            $qry = mysqli_query($this->con, "select*from user where username='$username'");
            if (mysqli_num_rows($qry) > 0) {
                while ($row = mysqli_fetch_assoc($qry)) {
                    if ($row['password'] == $password) {
                        $_SESSION['login'] = true;
                        $_SESSION['id'] = $row['id'];
                        $_SESSION['nama'] = $row['nama'];
                        $_SESSION['email'] = $row['email'];
                        $_SESSION['nipp'] = $row['nipp'];
                        $_SESSION['nomor'] = $row['nomor'];
                        $_SESSION['username'] = $row['username'];
                        $_SESSION['jabatan'] = $row['jabatan'];
                        $_SESSION['asal'] = $row['asal'];
                        $_SESSION['alamat'] = $row['alamat'];
                        $_SESSION['password'] = $row['password'];
                        $_SESSION['level'] = $row['level'];
                        $_SESSION['foto'] = $row['foto'];
                        echo "<script>location='../index.php'</script>";
                    } else {
                        echo "<script>alert('Password Salah')</script>";
                        return false;
                    }
                }
            } else {
                echo "<script>alert('Username Salah')</script>";
                return false;
            }
        }
    }
    public function profil($id)
    {
        if (isset($_POST["edit$id"])) {
            $username = $_POST['username'];
            $tentang = $_POST['tentang'];
            $nomor = $_POST['nomor'];
            $email = $_POST['email'];
            $cek = mysqli_query($this->con, "select*from user where username='$username'");
            if (mysqli_num_rows($cek) == 0) {
                $qry = mysqli_query($this->con, "update user set username='$username',tentang='$tentang',nomor='$nomor',email='$email' where id='$id'");
                if ($qry) {
                    echo "<script>location='?p=Profil'</script>";
                    return $qry;
                }
            } else {
                echo "<script>alert('Username Telah Terdaftar')</script>";
                return false;
            }
        }
        if (isset($_POST["gantipass$id"])) {
            $password = $_POST['password'];
            $newpassword = $_POST['newpassword'];
            $renewpassword = $_POST['renewpassword'];
            $qry = mysqli_query($this->con, "select*from user where id='$id'");
            while ($d = mysqli_fetch_assoc($qry)) {
                if ($password == $d['password']) {
                    if ($newpassword == $renewpassword) {
                        $update = mysqli_query($this->con, "update user set password='$newpassword' where id='$id'");
                        if ($update) {
                            echo "<script>alert('Berhasil Mengganti Password')</script>";
                            echo "<script>location='?p=Profil'</script>";
                            return $update;
                        }
                    } else {
                        echo "<script>alert('Password Tidak Sama')</script>";
                        return false;
                    }
                } else {
                    echo "<script>alert('Password Sebelumnya Salah')</script>";
                    return false;
                }
            }
        }
    }
    public function getdata($level)
    {
        $qry = mysqli_query($this->con, "select*from data_perangkat where level='$level'");
        if ($qry) {
            return $qry;
        }
    }
    public function check($id)
    {
        if (isset($_POST["check$id"])) {
            $qry = mysqli_query($this->con, "update data_perangkat set status='Baik' where id='$id'");
            if ($qry) {
                echo "<script>location='index.php'</script>";
                return $qry;
            }
        }
    }
    public function getdatadata($status, $level, $tanggal)
    {
        $qry = mysqli_query($this->con, "select*from data_perangkat where status='$status' and level='$level' and tanggal='$tanggal'");
        if ($qry) {
            return $qry;
        }
    }
    public function sesdata($id)
    {
        $qry = mysqli_query($this->con, "select*from user where id='$id'");
        if ($qry) {
            return $qry;
        }
    }
    public function getAkun($level)
    {
        $qry = mysqli_query($this->con, "select*from user where level='$level'");
        if ($qry) {
            return $qry;
        }
    }
    public function tambahAkun($level)
    {
        if (isset($_POST['tambah'])) {
            function uploadFoto()
            {
                if (isset($_FILES['foto'])) {
                    $namaFile = $_FILES['foto']['name'];
                    $ukuranFile = $_FILES['foto']['size'];
                    $error = $_FILES['foto']['error'];
                    $tmpName = $_FILES['foto']['tmp_name'];
                    if ($error === 4) {
                        echo
                        "<script>alert('File/Foto Gagal Dimasukkan')</script>";
                        return false;
                    }

                    $ekstensiFileValid = ['jpg', 'jpeg', 'jfif', 'png', 'webp'];
                    $ekstensiFile = explode('.', $namaFile);
                    $ekstensiFile = strtolower(end($ekstensiFile));
                    if (!in_array($ekstensiFile, $ekstensiFileValid)) {
                        echo
                        "<script>alert('File/Foto Tidak Sesuai Ekstensi : [jpg,jpeg,jfif,png,webp]')</script>";
                        return false;
                    }


                    if ($ukuranFile > 1000000) {
                        echo
                        "<script>alert('File/Foto Maximal 1MB')</script>";
                        return false;
                    }

                    $namaFileBaru = uniqid();
                    $namaFileBaru .= ".";
                    $namaFileBaru .= $ekstensiFile;

                    move_uploaded_file($tmpName, "assets/upload/" . $namaFileBaru);

                    return $namaFileBaru;
                } else {
                    return false;
                }
            }
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $nipp = $_POST['nipp'];
            $nomor = $_POST['nomor'];
            $username = $_POST['username'];
            $jabatan = $_POST['jabatan'];
            $asal = $_POST['asal'];
            $alamat = $_POST['alamat'];
            $password = $_POST['password'];
            $foto = uploadFoto();
            $cek = mysqli_query($this->con, "select*from user where username='$username'");
            if (mysqli_num_rows($cek) == 0) {
                $qry = mysqli_query($this->con, "insert into user values(null,'$nama','$email','$nipp','$nomor','$username','$jabatan','$asal','$alamat','$password','$level','$foto',null)");
                if ($qry) {
                    return $qry;
                }
            } else {
                echo "<script>alert('Username Telah Terdaftar')</script>";
                return false;
            }
        }
    }
    public function editAkun($id, $foto, $level)
    {
        if (isset($_POST["edit$id"])) {
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $nipp = $_POST['nipp'];
            $nomor = $_POST['nomor'];
            $username = $_POST['username'];
            $jabatan = $_POST['jabatan'];
            $asal = $_POST['asal'];
            $alamat = $_POST['alamat'];
            $password = $_POST['password'];
            $cek = mysqli_query($this->con, "select*from user where username='$username'");
            if (mysqli_num_rows($cek) == 0) {
                $qry = mysqli_query($this->con, "update user set nama='$nama',email='$email',nipp='$nipp',nomor='$nomor',username='$username',jabatan='$jabatan',asal='$asal',alamat='$alamat',password='$password',foto='$foto' where id='$id' and level='$level'");
                if ($qry) {
                    $page = ucfirst($level);
                    echo "<script>location='?d=Data Pengguna&p=$page'</script>";
                    return $qry;
                }
            } else {
                echo "<script>alert('Username Telah Terdaftar')</script>";
                return false;
            }
        }
    }
    public function deleteAkun($id, $level)
    {
        if (isset($_POST["delete$id"])) {
            $qry = mysqli_query($this->con, "delete from user where id='$id'");
            if ($qry) {
                $page = ucfirst($level);
                echo "<script>location='?d=Data Pengguna&p=$page'</script>";
                return $qry;
            }
        }
    }
    public function getDataPerangkat($level)
    {
        $qry = mysqli_query($this->con, "select*from data_perangkat where level='$level'");
        if ($qry) {
            return $qry;
        }
    }
    public function getDataPerangkats($level, $tanggal)
    {
        $qry = mysqli_query($this->con, "select*from data_perangkat where level='$level' and tanggal='$tanggal'");
        if ($qry) {
            return $qry;
        }
    }
    public function tambahDataPerangkat($level)
    {
        if (isset($_POST['tambah'])) {
            function uploadFoto()
            {
                if (isset($_FILES['foto'])) {
                    $namaFile = $_FILES['foto']['name'];
                    $ukuranFile = $_FILES['foto']['size'];
                    $error = $_FILES['foto']['error'];
                    $tmpName = $_FILES['foto']['tmp_name'];
                    if ($error === 4) {
                        echo
                        "<script>alert('File/Foto Gagal Dimasukkan')</script>";
                        return false;
                    }

                    $ekstensiFileValid = ['jpg', 'jpeg', 'jfif', 'png', 'webp'];
                    $ekstensiFile = explode('.', $namaFile);
                    $ekstensiFile = strtolower(end($ekstensiFile));
                    if (!in_array($ekstensiFile, $ekstensiFileValid)) {
                        echo
                        "<script>alert('File/Foto Tidak Sesuai Ekstensi : [jpg,jpeg,jfif,png,webp]')</script>";
                        return false;
                    }


                    if ($ukuranFile > 1000000) {
                        echo
                        "<script>alert('File/Foto Maximal 1MB')</script>";
                        return false;
                    }

                    $namaFileBaru = uniqid();
                    $namaFileBaru .= ".";
                    $namaFileBaru .= $ekstensiFile;

                    move_uploaded_file($tmpName, "assets/upload/" . $namaFileBaru);

                    return $namaFileBaru;
                } else {
                    return false;
                }
            }
            $kode = $_POST['kode'];
            $jenis = $_POST['jenis'];
            $nama = $_POST['nama'];
            $status = $_POST['status'];
            $foto = uploadFoto();
            $date = date("Y-m-d");
            $qry = mysqli_query($this->con, "insert into data_perangkat values(null,'$kode','$foto','$jenis','$nama','$status','$level','$date')");
            if ($qry) {
                $page = ucfirst($level);
                echo "<script>location='?d=Data Perangkat&p=$page'</script>";
                return $qry;
            }
        }
        if (isset($_POST['tambahlocotrack'])) {
            function uploadFoto()
            {
                if (isset($_FILES['foto'])) {
                    $namaFile = $_FILES['foto']['name'];
                    $ukuranFile = $_FILES['foto']['size'];
                    $error = $_FILES['foto']['error'];
                    $tmpName = $_FILES['foto']['tmp_name'];
                    if ($error === 4) {
                        echo
                        "<script>alert('File/Foto Gagal Dimasukkan')</script>";
                        return false;
                    }

                    $ekstensiFileValid = ['jpg', 'jpeg', 'jfif', 'png', 'webp'];
                    $ekstensiFile = explode('.', $namaFile);
                    $ekstensiFile = strtolower(end($ekstensiFile));
                    if (!in_array($ekstensiFile, $ekstensiFileValid)) {
                        echo
                        "<script>alert('File/Foto Tidak Sesuai Ekstensi : [jpg,jpeg,jfif,png,webp]')</script>";
                        return false;
                    }


                    if ($ukuranFile > 1000000) {
                        echo
                        "<script>alert('File/Foto Maximal 1MB')</script>";
                        return false;
                    }

                    $namaFileBaru = uniqid();
                    $namaFileBaru .= ".";
                    $namaFileBaru .= $ekstensiFile;

                    move_uploaded_file($tmpName, "assets/upload/" . $namaFileBaru);

                    return $namaFileBaru;
                } else {
                    return false;
                }
            }
            $kode = $_POST['kode'];
            $nama = $_POST['nama'];
            $status = $_POST['status'];
            $foto = uploadFoto();
            $date = date("Y-m-d");
            $qry = mysqli_query($this->con, "insert into data_perangkat values(null,'$kode','$foto',null,'$nama','$status','$level','$date')");
            if ($qry) {
                $page = ucfirst($level);
                echo "<script>location='?d=Data Perangkat&p=$page'</script>";
                return $qry;
            }
        }
    }
    public function editDataPerangkat($id, $foto, $level)
    {
        if (isset($_POST["edit$id"])) {
            $kode = $_POST['kode'];
            $jenis = $_POST['jenis'];
            $nama = $_POST['nama'];
            $status = $_POST['status'];
            $qry = mysqli_query($this->con, "update data_perangkat set kode='$kode',jenis='$jenis',nama='$nama',status='$status', foto='$foto' where id='$id' and level='$level'");
            if ($qry) {
                $page = ucfirst($level);
                echo "<script>location='?d=Data Perangkat&p=$page'</script>";
                return $qry;
            }
        }
        if (isset($_POST["editlocotrack$id"])) {
            $kode = $_POST['kode'];
            $nama = $_POST['nama'];
            $status = $_POST['status'];
            $qry = mysqli_query($this->con, "update data_perangkat set kode='$kode',nama='$nama',status='$status', foto='$foto' where id='$id' and level='$level'");
            if ($qry) {
                $page = ucfirst($level);
                echo "<script>location='?d=Data Perangkat&p=$page'</script>";
                return $qry;
            }
        }
    }
    public function deleteDataPerangkat($id, $level)
    {
        if (isset($_POST["delete$id"])) {
            $qry = mysqli_query($this->con, "delete from data_perangkat where id='$id'");
            if ($qry) {
                $page = ucfirst($level);
                echo "<script>location='?d=Data Perangkat&p=$page'</script>";
                return $qry;
            }
        }
    }
}
