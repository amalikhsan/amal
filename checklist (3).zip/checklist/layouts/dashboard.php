<?php
if (!isset($_SESSION['login'])) {
    echo "<script>location='assets/'</script>";
}
?>
<section class="section dashboard">
    <div class="row">
        <div class="col-lg-8">
            <div class="row">
                <div class="col-xxl-4 col-xl-12">
                    <div class="card info-card customers-card">
                        <div class="card-body">
                            <h5 class="card-title">Jumlah CCTV</h5>
                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center"> <i class="bi bi-camera-video"></i></div>
                                <div class="ps-3">
                                    <?php
                                    $result = $db->getdata("CCTV Gerbong");
                                    $d = mysqli_num_rows($result);
                                    ?>
                                    <h6><?= $d ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-12">
                    <div class="card info-card customers-card">
                        <div class="card-body">
                            <h5 class="card-title">Jumlah Locotrack</h5>
                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center"> <i class="bi bi-cart"></i></div>
                                <div class="ps-3">
                                    <?php
                                    $result = $db->getdata("Locotrack");
                                    $d = mysqli_num_rows($result);
                                    ?>
                                    <h6><?= $d ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-12">
                    <div class="card info-card customers-card">
                        <div class="card-body">
                            <h5 class="card-title">Jumlah Perangkat IT</h5>
                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center"> <i class="bi bi-currency-dollar"></i></div>
                                <div class="ps-3">
                                    <?php
                                    $result = $db->getdata("Perangkat IT");
                                    $d = mysqli_num_rows($result);
                                    ?>
                                    <h6><?= $d ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body">
                            <h5 class="card-title">Jadwal Kerja Teknisi</h5>
                            <table class="table table-borderless" id="dataTable4">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Username</th>
                                        <th scope="col">Level</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">#2457</th>
                                        <td>Brandon Jacob</td>
                                        <td>$64</td>
                                        <td>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Daftar CCTV Gerbong</h5>
                            <div id="reportsChart"></div>
                            <?php
                            $date = date("Y-m-d");
                            $date1 = str_replace('-', '/', $date);
                            $date2 = date('Y-m-d', strtotime($date1 . "-1 days"));
                            $date3 = date('Y-m-d', strtotime($date1 . "-2 days"));
                            $baik = mysqli_num_rows($db->getdatadata("Baik", "CCTV Gerbong", $date));
                            $pemeliharaan = mysqli_num_rows($db->getdatadata("Pemeliharaan", "CCTV Gerbong", $date));
                            $rusak = mysqli_num_rows($db->getdatadata("Rusak", "CCTV Gerbong", $date));
                            $baik2 = mysqli_num_rows($db->getdatadata("Baik", "CCTV Gerbong", $date2));
                            $pemeliharaan2 = mysqli_num_rows($db->getdatadata("Pemeliharaan", "CCTV Gerbong", $date2));
                            $rusak2 = mysqli_num_rows($db->getdatadata("Rusak", "CCTV Gerbong", $date2));
                            $baik3 = mysqli_num_rows($db->getdatadata("Baik", "CCTV Gerbong", $date3));
                            $pemeliharaan3 = mysqli_num_rows($db->getdatadata("Pemeliharaan", "CCTV Gerbong", $date3));
                            $rusak3 = mysqli_num_rows($db->getdatadata("Rusak", "CCTV Gerbong", $date3));
                            ?>
                            <script>
                                document.addEventListener("DOMContentLoaded", () => {
                                    new ApexCharts(document.querySelector("#reportsChart"), {
                                        series: [{
                                            name: 'Perangkat keadaan baik',
                                            data: [<?= $baik3 ?>, <?= $baik2 ?>, <?= $baik ?>],
                                        }, {
                                            name: 'Perangkat keadaan Pemeliharaan',
                                            data: [<?= $pemeliharaan3 ?>, <?= $pemeliharaan2 ?>, <?= $pemeliharaan ?>]
                                        }, {
                                            name: 'Perangkat keadaan Rusak',
                                            data: [<?= $rusak3 ?>, <?= $rusak2 ?>, <?= $rusak ?>]
                                        }],
                                        chart: {
                                            height: 350,
                                            type: 'area',
                                            toolbar: {
                                                show: false
                                            },
                                        },
                                        markers: {
                                            size: 4
                                        },
                                        colors: ['#198754', '#ffc107', '#dc3545'],
                                        fill: {
                                            type: "gradient",
                                            gradient: {
                                                shadeIntensity: 1,
                                                opacityFrom: 0.3,
                                                opacityTo: 0.4,
                                                stops: [0, 90, 100]
                                            }
                                        },
                                        dataLabels: {
                                            enabled: false
                                        },
                                        stroke: {
                                            curve: 'smooth',
                                            width: 2
                                        },
                                        xaxis: {
                                            type: 'datetime',
                                            categories: ["<?= $date3 ?>", "<?= $date2 ?>", "<?= $date ?>"]
                                        },
                                        tooltip: {
                                            x: {
                                                format: 'dd/MM/yy HH:mm'
                                            },
                                        }
                                    }).render();
                                });
                            </script>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body">
                            <h5 class="card-title">Checklist Perangkat IT</h5>
                            <table class="table table-borderless" id="dataTable5">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Kode</th>
                                        <th scope="col">Foto</th>
                                        <th scope="col">Jenis Perangkat IT</th>
                                        <th scope="col">Nama Perangkat IT</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Checklist</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    $result = $db->getDataPerangkats('Perangkat IT', date("Y-m-d"));
                                    while ($d = mysqli_fetch_assoc($result)) {
                                    ?>
                                        <tr>
                                            <th scope="row"><?= $i++ ?></th>
                                            <td><?= $d['kode'] ?></td>
                                            <td><img src="assets/upload/<?= $d['foto'] ?>" width="100"></td>
                                            <td><?= $d['jenis'] ?></td>
                                            <td><?= $d['nama'] ?></td>
                                            <td>
                                                <?php if ($d['status'] == "Baik") { ?>
                                                    <span class="badge bg-success"><?= $d['status'] ?></span>
                                                <?php } ?>
                                                <?php if ($d['status'] == "Pemeliharaan") { ?>
                                                    <span class="badge bg-warning"><?= $d['status'] ?></span>
                                                <?php } ?>
                                                <?php if ($d['status'] == "Rusak") { ?>
                                                    <span class="badge bg-danger"><?= $d['status'] ?></span>
                                                <?php } ?>
                                            </td>
                                            <td class="text-center">
                                                <button class="btn btn-success btn-sm" onclick="check(<?= $d['id'] ?>)" id="btn<?= $d['id'] ?>"><i class="bi bi-check"></i></button>
                                                <i class="bi bi-check text-success fs-4 d-none" id="check<?= $d['id'] ?>"></i>
                                            </td>
                                        </tr>
                                        <script>
                                            function check(id) {
                                                const check = document.getElementById('check' + id);
                                                const btn = document.getElementById('btn' + id);
                                                check.classList.add('d-block');
                                                check.classList.remove('d-none');
                                                btn.classList.add('d-none');
                                                btn.classList.remove('d-block');
                                                localStorage.setItem('check', true);
                                                localStorage.setItem('id' + id, id);
                                            }
                                            if (localStorage.getItem('check')) {
                                                const ids = localStorage.getItem('id' + <?= $d['id'] ?>);
                                                check(ids);
                                            }
                                        </script>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body">
                            <h5 class="card-title">Daftar Perangkat IT</h5>
                            <table class="table table-borderless" id="dataTable5">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Kode</th>
                                        <th scope="col">Foto</th>
                                        <th scope="col">Jenis Perangkat IT</th>
                                        <th scope="col">Nama Perangkat IT</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    $result = $db->getDataPerangkat('Perangkat IT');
                                    while ($d = mysqli_fetch_assoc($result)) {
                                    ?>
                                        <tr>
                                            <th scope="row"><?= $i++ ?></th>
                                            <td><?= $d['kode'] ?></td>
                                            <td><img src="assets/upload/<?= $d['foto'] ?>" width="100"></td>
                                            <td><?= $d['jenis'] ?></td>
                                            <td><?= $d['nama'] ?></td>
                                            <td>
                                                <?php if ($d['status'] == "Baik") { ?>
                                                    <span class="badge bg-success"><?= $d['status'] ?></span>
                                                <?php } ?>
                                                <?php if ($d['status'] == "Pemeliharaan") { ?>
                                                    <span class="badge bg-warning"><?= $d['status'] ?></span>
                                                <?php } ?>
                                                <?php if ($d['status'] == "Rusak") { ?>
                                                    <span class="badge bg-danger"><?= $d['status'] ?></span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Aktivitas Terkini </h5>
                    <div class="activity">
                        <div class="activity-item d-flex">
                            <div class="activite-label">32 menit</div>
                            <i class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
                            <div class="activity-content"> Pengecekan Terhadap <a href="#" class="fw-bold text-dark">CCTV Gerbong 1</a> Terverifikasi</div>
                        </div>
                        <div class="activity-item d-flex">
                            <div class="activite-label">56 menit</div>
                            <i class='bi bi-circle-fill activity-badge text-danger align-self-start'></i>
                            <div class="activity-content"> Pendataan Perangkat IT Sesuai Dengan Kelompok</div>
                        </div>
                        <div class="activity-item d-flex">
                            <div class="activite-label">2 jam</div>
                            <i class='bi bi-circle-fill activity-badge text-primary align-self-start'></i>
                            <div class="activity-content"> Melakukan Maintenance Perangkat IT</div>
                        </div>
                        <div class="activity-item d-flex">
                            <div class="activite-label">1 hari</div>
                            <i class='bi bi-circle-fill activity-badge text-info align-self-start'></i>
                            <div class="activity-content"> Perubahan Jadwal Kerja Harian Teknisi <a href="#" class="fw-bold text-dark">Disetujui</a> Oleh Admin</div>
                        </div>
                        <div class="activity-item d-flex">
                            <div class="activite-label">2 hari</div>
                            <i class='bi bi-circle-fill activity-badge text-warning align-self-start'></i>
                            <div class="activity-content"> Penambahan Daftar Perangkat IT</div>
                        </div>
                        <div class="activity-item d-flex">
                            <div class="activite-label">4 hari</div>
                            <i class='bi bi-circle-fill activity-badge text-muted align-self-start'></i>
                            <div class="activity-content"> Mengganti Perangkat yang Tidak Bisa Dipakai</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body pb-0">
                    <h5 class="card-title">Jumlah Perangkat</h5>
                    <div id="trafficChart" style="min-height: 400px;" class="echart"></div>
                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                            echarts.init(document.querySelector("#trafficChart")).setOption({
                                tooltip: {
                                    trigger: 'item'
                                },
                                legend: {
                                    top: '5%',
                                    left: 'center'
                                },
                                series: [{
                                    name: 'Access From',
                                    type: 'pie',
                                    radius: ['40%', '70%'],
                                    avoidLabelOverlap: false,
                                    label: {
                                        show: false,
                                        position: 'center'
                                    },
                                    emphasis: {
                                        label: {
                                            show: true,
                                            fontSize: '18',
                                            fontWeight: 'bold'
                                        }
                                    },
                                    labelLine: {
                                        show: false
                                    },
                                    data: [{
                                            value: 11,
                                            name: 'Laptop'
                                        },
                                        {
                                            value: 4,
                                            name: 'Switch'
                                        },
                                        {
                                            value: 6,
                                            name: 'Computer'
                                        },
                                        {
                                            value: 8,
                                            name: 'Router'
                                        },
                                        {
                                            value: 10,
                                            name: 'Printer'
                                        }
                                    ]
                                }]
                            });
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
</section>